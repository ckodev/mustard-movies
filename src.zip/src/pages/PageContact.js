import React from 'react'

function PageContact() {
  return (
    <div className='home-page'>
        <h1>This the Contact page!</h1>
        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Labore dicta error eos, illo nulla, deserunt atque nobis, praesentium porro ipsa quibusdam aut dolores! Voluptate, maiores!</p>
    </div>
  )
}

export default PageContact
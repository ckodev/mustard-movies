//https://api.themoviedb.org/3/movie/popular?api_key=cb69fcedf68e151565f2200910579334&language=en-US&page=1

export const API_KEY = 'cb69fcedf68e151565f2200910579334';
export const appStorageName = 'movie-app-favs';
export const appTitle = 'Movie App';
